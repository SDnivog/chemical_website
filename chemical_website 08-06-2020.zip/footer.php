<!-- FOOTER --->
<footer class="text-light" style="background: #2a0d8e;">
	<div class="container">
		<div class="row">
			<div class="col  mt-4">
			<p class=""> &copy; Copyright <span id="year"></span>, All right Reserved by NIT Jalandhar<br><b>Developed By :</b> <a class="text-light" href="https://www.linkedin.com/in/govind-suman-b900b5174/">GOVIND</a> </p>
			
		</div>
		<!--
		<div class="col lg-4">
			<p class="icon">
				<ul style="list-style: none;float: left;">
					<li><a href=""> <i class="fab fa-facebook text-info" ></i></a></li>
					<li><a href=""> <i class="fab fa-instagram text-danger"></i></a></li>
					<li><a href=""> <i class="fab fa-youtube text-danger"></i></a></li>
				</ul>
			</p>
		</div> -->
		</div>
	</div>
</footer>