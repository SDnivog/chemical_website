
  <div class="container-fluid" style="background: #17119a">
  <div class="row" style="background-color:#FECD0B; height:4px"> </div>

  <div class="container">
    <div class="row">
        <div class="col-md-12" style="padding-top:12px">
          <div>
            <p style="color: #fff; float: right;"><a style="color: #fff;" href="#"> <i class="fas fa-sign-in-alt"></i> Login</a><br><a style="color: #fff;" href="https://classroom.google.com/u/0/h">Class Room</a></p>
          </div>
            <div class="logo">
               <div id="time" style="color: #ffff;margin-left: 30px;"> </div>
                <a href="index.php" title="NIT Jalandhar" rel="home"></a>
                    <img style="" src="http://localhost/chemical_f/Images/logo2.png" alt="NIT Jalandhar"/></a><br>
                    <p style="font-family: Time New Roman; font-size: 22px;line-height: 30px; color: #fff;margin-left: 120px; margin-top: -70px;">
                      Dr B R Ambedkar National Institute of Technology, Jalandhar<br> Department of Chemical Engineering 
                    </p>
                
            </div><!-- /.logo -->
            
            <div class="logo2" style="margin-bottom: -70px;">
                <a href="index.php" title="NIT Jalandhar" rel="home"></a>
                    <img src="http://localhost/chemical_f/Images/logo2.png" alt="NIT Jalandhar"/></a><br /><br />
              <p style="width:100%; font-family:Times New Roman; letter-spacing:1px; font-size:22px; color:white; line-height:30px;">
              Dr B R Ambedkar National Institute of Technology, Jalandhar<br> Department of Chemical Engineering<br><br><br><br></p>
            </div> 
        </div> 
    </div>
  </div>
</div>

<!--
<div class="container-fluid" style="background: #17119a;">
  <div class="row">
    <div class="col-lg-3">
       <div id="time" style="color: #ffff;margin-left: 30px;"> </div><br>
      <img src="Images/logo2.png" class="mb-3 ml-3 image-fluid" style="width: 150px; height: 150px;">
    </div>
    <div class="col-lg-7 text-light mt-4">
      <div></div>
      <p style="font-family: Time New Roman; font-size: 22px;">Dr B R Ambedkar National Institute of Technology, Jalandhar<br> Department of Chemical Engineering </p>
    </div>
    <div class="col-lg-2 d-none">
      <ul>
        <li><a href="#">Login</a></li>
        <li><a href="#">Class Room</a></li>
      </ul>
    </div>
  </div>
</div> -->


